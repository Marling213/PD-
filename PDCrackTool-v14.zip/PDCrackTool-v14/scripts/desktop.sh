#!/bin/bash

[ -f "scripts/utils.sh" ] && source "scripts/utils.sh" || {
  echo "Error: utils.sh not found"
  exit 1
}

[ -f "scripts/menu.sh" ] && source "scripts/menu.sh" || {
  echo "Error: menu.sh not found"
  exit 1
}

patch_file() {
  local file_path="$1"
  print_info "${MSG_PROCESSING_FILE}: $(basename "$file_path")"

  if [ ! -f "${file_path}_backup" ]; then
    run_cmd "cp '$file_path' '${file_path}_backup'" "${MSG_CLEARING_ATTR} ${file_path}_backup" "${MSG_BACKUP_CREATED}" || return 1
  fi

  run_cmd "cp '${file_path}_backup' '$file_path'" "${MSG_CLEARING_ATTR} 从备份恢复文件: $file_path" "${MSG_BACKUP_RESTORED}" || return 1
  run_cmd "'./insert_dylib' '@rpath/$DYLIB' '$file_path' '$file_path.tmp'" "${MSG_CLEARING_ATTR} 注入动态库到: $file_path" "${MSG_INJECTING}" || return 1
  run_cmd "mv '$file_path.tmp' '$file_path'" "${MSG_CLEARING_ATTR} 替换原始文件: $file_path" "${MSG_REPLACING}" || return 1
  run_cmd "sudo codesign -f -s - --timestamp=none --all-architectures --entitlements './VM.entitlements' '$file_path'" \
    "${MSG_CLEARING_ATTR} 签名文件: $file_path" "${MSG_SIGNING}" || return 1

  print_info "${MSG_PROCESSING_SUCCESS}: $(basename "$file_path")"
  return 0
}

crack_desktop() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"

  local PD_VERSIONS=(
    "20.3.1-55959" "20.3.0-55895" "20.2.2-55879" "20.2.1-55876" "20.2.0-55872"
    "20.1.3-55743" "20.1.2-55742" "20.1.1-55740" "19.4.1-54985"
    "18.3.3-53627" "18.1.0-53311"
  )

  clear
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_TITLE}${MSG_SELECT_VERSION}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  for i in "${!PD_VERSIONS[@]}"; do
    full_version="${PD_VERSIONS[$i]}"
    base_version="${full_version%-*}"
    build_number="${full_version#*-}"

    printf "${COLOR_SELECT}%2d)${NOCOLOR} Parallels Desktop ${COLOR_VERSION}%s${NOCOLOR} (${MSG_BUILD}: ${COLOR_BUILD}%s${NOCOLOR})\n" \
      $((i + 1)) "$base_version" "$build_number"
  done

  local VERSION_COUNT=${#PD_VERSIONS[@]}
  printf "${COLOR_SELECT}%2d)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n" $((VERSION_COUNT + 1))
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  read -p "${MSG_OPTION} [1-$((VERSION_COUNT + 1))]: " version_choice

  if [ "$version_choice" -eq $((VERSION_COUNT + 1)) ]; then
    main_menu
    return
  fi

  local PDFM_VER=""
  if [[ "$version_choice" =~ ^[0-9]+$ ]] && [ "$version_choice" -ge 1 ] && [ "$version_choice" -le "$VERSION_COUNT" ]; then
    PDFM_VER="${PD_VERSIONS[$((version_choice - 1))]}"
  else
    PDFM_VER="${PD_VERSIONS[0]}"
    printf "${COLOR_ERROR}[${MSG_ERROR}] ${MSG_INVALID_OPTION} %s${NOCOLOR}\n" "${PDFM_VER%-*}"
  fi

  local base_version="${PDFM_VER%-*}"
  print_info "${MSG_SELECTED}: Parallels Desktop $base_version (${PDFM_VER})"

  local ParaHome='/Applications/Parallels Desktop.app'
  local DYLIB="CoreInject.dylib"
  local prl_disp_service="${ParaHome}/Contents/MacOS/Parallels Service.app/Contents/MacOS/prl_disp_service"
  local prl_vm_app="${ParaHome}/Contents/MacOS/Parallels VM.app/Contents/MacOS/prl_vm_app"
  local prl_client_app="${ParaHome}/Contents/MacOS/prl_client_app"

  local major_version="${base_version%%.*}"
  local download_url="https://download.parallels.com/desktop/v${major_version}/${PDFM_VER}/ParallelsDesktop-${PDFM_VER}.dmg"
  local download_filename="ParallelsDesktop-${PDFM_VER}.dmg"

  if [ ! -d "$ParaHome" ]; then
    ask_download "$download_url" "$download_filename" "Parallels Desktop" || exit 1
  fi

  [ ! -f "./$DYLIB" ] && {
    print_error "核心注入文件 $DYLIB 不存在，请确保文件在当前目录"
    exit 1
  }
  [ ! -f "./insert_dylib" ] && {
    print_error "insert_dylib 工具不存在，请确保文件在当前目录"
    exit 1
  }
  [ ! -f "./VM.entitlements" ] && {
    print_error "VM.entitlements 文件不存在，请确保文件在当前目录"
    exit 1
  }
  [ ! -f "$prl_disp_service" ] && {
    print_error "找不到 prl_disp_service 文件"
    exit 1
  }
  [ ! -f "$prl_vm_app" ] && {
    print_error "找不到 prl_vm_app 文件"
    exit 1
  }
  [ ! -f "$prl_client_app" ] && {
    print_error "找不到 prl_client_app 文件"
    exit 1
  }

  print_info "${MSG_ENSURE_VERSION}: ${download_url}"

  if pgrep -x "prl_disp_service" &>/dev/null; then
    print_info "${MSG_STOPPING_PD}"
    pkill -9 prl_client_app &>/dev/null

    output=$("${ParaHome}/Contents/MacOS/Parallels Service" service_stop 2>&1)
    check_permission_error "$output" 0 "${MSG_STOPPING_PD}"

    output=$(launchctl stop /Library/LaunchDaemons/com.parallels.desktop.launchdaemon.plist 2>&1)
    check_permission_error "$output" 0 "停止 Parallels Desktop 启动服务"

    pkill -9 prl_disp_service &>/dev/null
    sleep 1

    rm -f "/var/run/prl_*" 2>/dev/null
  fi

  xattr -cr "./$DYLIB" ./* 2>/dev/null || run_cmd "xattr -cr './$DYLIB' ./*" "${MSG_CLEARING_ATTR}" "${MSG_CLEARING_ATTR}"

  print_info "${MSG_COPYING_CORE}"
  run_cmd "sudo cp './$DYLIB' '${ParaHome}/Contents/Frameworks/$DYLIB'" \
    "${MSG_CLEARING_ATTR} $DYLIB 到 ${ParaHome}/Contents/Frameworks/" "${MSG_COPYING_CORE}"

  print_info "${MSG_SIGNING_CORE}"
  run_cmd "sudo codesign -fs - '${ParaHome}/Contents/Frameworks/$DYLIB'" \
    "${MSG_CLEARING_ATTR} $DYLIB" "${MSG_SIGNING_CORE}"

  run_cmd "chmod +x ./insert_dylib" "${MSG_CLEARING_ATTR} insert_dylib" "${MSG_SET_EXEC_PERM}"

  print_info "${MSG_INJECT_DYLIB}"

  patch_file "$prl_disp_service" || {
    print_error "${MSG_PROCESSING_FAILED} ${MSG_CRACK_COMPLETE}"
    exit 1
  }
  patch_file "$prl_vm_app" || {
    print_error "${MSG_PROCESSING_FAILED} ${MSG_CRACK_COMPLETE}"
    exit 1
  }
  patch_file "$prl_client_app" || {
    print_error "${MSG_PROCESSING_FAILED} ${MSG_CRACK_COMPLETE}"
    exit 1
  }

  print_info "${MSG_CRACK_COMPLETE}"

  # 启动 prl_disp_service
  if ! pgrep -x "prl_disp_service" &>/dev/null; then
    print_info "正在启动 Parallels Service ..."
    "$ParaHome/Contents/MacOS/Parallels Service" service_restart &>/dev/null
    for ((i = 0; i < 10; ++i)); do
      if pgrep -x "prl_disp_service" &>/dev/null; then
        break
      fi
      sleep 1
    done
    if ! pgrep -x "prl_disp_service" &>/dev/null; then
      print_error "启动 Service 失败."
    fi
  fi

  # 配置 parallels
  "$ParaHome/Contents/MacOS/prlsrvctl" web-portal signout &>/dev/null
  "$ParaHome/Contents/MacOS/prlsrvctl" set --cep off &>/dev/null
  "$ParaHome/Contents/MacOS/prlsrvctl" set --allow-attach-screenshots off &>/dev/null

  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} ${MSG_EXIT}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "${MSG_OPTION} [1-2]: " choice
  case "$choice" in
  1)
    main_menu
    ;;
  *)
    exit 0
    ;;
  esac
}
