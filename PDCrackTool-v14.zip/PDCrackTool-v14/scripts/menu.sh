#!/bin/bash

[ -f "scripts/utils.sh" ] && source "scripts/utils.sh" || {
  echo "Error: utils.sh not found"
  exit 1
}

language_menu() {
  clear
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_TITLE}Select Language / 选择语言:${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} English\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} 中文\n"
  printf "${COLOR_SELECT}3)${NOCOLOR} Français\n"
  printf "${COLOR_SELECT}4)${NOCOLOR} Español\n"
  printf "${COLOR_SELECT}5)${NOCOLOR} Deutsch\n"
  printf "${COLOR_SELECT}6)${NOCOLOR} Italiano\n"
  printf "${COLOR_SELECT}7)${NOCOLOR} Português\n"
  printf "${COLOR_SELECT}8)${NOCOLOR} Русский\n"
  printf "${COLOR_SELECT}9)${NOCOLOR} 日本語\n"
  printf "${COLOR_SELECT}0)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_VERSION}Current / 当前: ${LANGUAGE}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "Enter option/请输入选项 [0-9]: " lang_choice

  case "$lang_choice" in
  1) load_language "en_US" ;;
  2) load_language "zh_CN" ;;
  3) load_language "fr_FR" ;;
  4) load_language "es_ES" ;;
  5) load_language "de_DE" ;;
  6) load_language "it_IT" ;;
  7) load_language "pt_BR" ;;
  8) load_language "ru_RU" ;;
  9) load_language "ja_JP" ;;
  0) return 0 ;;
  esac

  main_menu
}

main_menu() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"

  clear
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_TITLE}${MSG_SELECT_PRODUCT}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} Parallels Desktop\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} Parallels Toolbox\n"
  printf "${COLOR_SELECT}3)${NOCOLOR} ${MSG_SWITCH_LANGUAGE}\n"
  printf "${COLOR_SELECT}4)${NOCOLOR} ${MSG_BATCH_DOWNLOAD_DMG}\n"
  printf "${COLOR_SELECT}5)${NOCOLOR} ${MSG_EXIT}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_VERSION}Developer: QiuChenly / 秋城落叶${NOCOLOR}\n"
  printf "${COLOR_VERSION}Telegram: https://t.me/qiuchenlymac${NOCOLOR}\n"
  printf "${COLOR_VERSION}TG聊天频道: https://t.me/+VvqTr-2EFaZhYzA1${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "${MSG_OPTION} [1-5]: " product_choice

  case "$product_choice" in
  1)
    clear
    source "scripts/desktop.sh"
    crack_desktop
    ;;
  2)
    clear
    source "scripts/toolbox.sh"
    crack_toolbox
    ;;
  3) language_menu ;;
  4) batch_download_dmg ;;
  5) exit 0 ;;
  *)
    print_error "${MSG_INVALID_OPTION}"
    sleep 2
    main_menu
    ;;
  esac
}

ask_download() {
  local url="$1"
  local filename="$2"
  local product_name="$3"

  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"

  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_ERROR}[${MSG_ERROR}] ${product_name} ${MSG_PD_NOT_INSTALLED}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_INFO}${MSG_OPTION} ${product_name}?${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} ${MSG_YES}\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} ${MSG_NO}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "${MSG_OPTION} [1-2]: " download_choice

  case "$download_choice" in
  1)
    source "scripts/download.sh"
    download_file "$url" "$filename"
    printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
    printf "${COLOR_INFO}[${MSG_INFO}] ${MSG_CONTINUE_AFTER_INSTALL}${NOCOLOR}\n"
    printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
    read -n 1 -s
    return 0
    ;;
  *)
    print_info "${MSG_CANCELLED}"
    exit 0
    ;;
  esac
}

# 新增函数：批量下载DMG文件
batch_download_dmg() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"

  local cache_dir="./downloads"

  [ ! -d "$cache_dir" ] && {
    mkdir -p "$cache_dir"
    sudo chmod 777 "$cache_dir"
    sudo chown $(whoami):$(id -gn) "$cache_dir"
  }

  clear
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_TITLE}${MSG_BATCH_DOWNLOAD_DMG}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  # 选择产品类型
  printf "${COLOR_INFO}${MSG_SELECT_PRODUCT_TYPE}:${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} Parallels Desktop\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} Parallels Toolbox\n"
  printf "${COLOR_SELECT}3)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "${MSG_ENTER_OPTION} [1-3]: " product_choice

  if [ "$product_choice" -eq 3 ]; then
    main_menu
    return
  fi

  local download_list=()

  if [ "$product_choice" -eq 1 ]; then
    # Parallels Desktop 版本列表
    local PD_VERSIONS=(
      "20.3.1-55959" "20.3.0-55895" "20.2.2-55879" "20.2.1-55876" "20.2.0-55872"
      "20.1.3-55743" "20.1.2-55742" "20.1.1-55740" "19.4.1-54985"
      "18.3.3-53627" "18.1.0-53311"
    )

    printf "${COLOR_INFO}${MSG_SELECT_FILES_TO_DOWNLOAD}:${NOCOLOR}\n"

    for i in "${!PD_VERSIONS[@]}"; do
      full_version="${PD_VERSIONS[$i]}"
      base_version="${full_version%-*}"
      build_number="${full_version#*-}"

      printf "${COLOR_SELECT}%2d)${NOCOLOR} Parallels Desktop ${COLOR_VERSION}%s${NOCOLOR} (${MSG_BUILD}: ${COLOR_BUILD}%s${NOCOLOR})\n" \
        $((i + 1)) "$base_version" "$build_number"
    done

    printf "${COLOR_SELECT}%2d)${NOCOLOR} ${MSG_DOWNLOAD_ALL_FILES}\n" $((${#PD_VERSIONS[@]} + 1))
    printf "${COLOR_SELECT}%2d)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n" $((${#PD_VERSIONS[@]} + 2))
    printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

    read -p "${MSG_ENTER_OPTION} [1-$((${#PD_VERSIONS[@]} + 2))]: " choice

    if [ "$choice" -eq $((${#PD_VERSIONS[@]} + 2)) ]; then
      main_menu
      return
    elif [ "$choice" -eq $((${#PD_VERSIONS[@]} + 1)) ]; then
      # 选择下载所有文件
      for ver in "${PD_VERSIONS[@]}"; do
        local major_version="${ver%%.*}"
        local url="https://download.parallels.com/desktop/v${major_version}/${ver}/ParallelsDesktop-${ver}.dmg"
        local filename="ParallelsDesktop-${ver}.dmg"
        download_list+=("$url|$filename")
      done
    elif [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#PD_VERSIONS[@]}" ]; then
      # 选择单个文件
      local ver="${PD_VERSIONS[$((choice - 1))]}"
      local major_version="${ver%%.*}"
      local url="https://download.parallels.com/desktop/v${major_version}/${ver}/ParallelsDesktop-${ver}.dmg"
      local filename="ParallelsDesktop-${ver}.dmg"
      download_list+=("$url|$filename")
    else
      print_error "${MSG_INVALID_OPTION}"
      sleep 2
      batch_download_dmg
      return
    fi
  elif [ "$product_choice" -eq 2 ]; then
    # Parallels Toolbox 版本列表
    local PT_VERSIONS=(
      "7.0.0-5272"
    )

    printf "${COLOR_INFO}${MSG_SELECT_FILES_TO_DOWNLOAD}:${NOCOLOR}\n"

    for i in "${!PT_VERSIONS[@]}"; do
      full_version="${PT_VERSIONS[$i]}"
      base_version="${full_version%-*}"
      build_number="${full_version#*-}"

      printf "${COLOR_SELECT}%2d)${NOCOLOR} Parallels Toolbox ${COLOR_VERSION}%s${NOCOLOR} (${MSG_BUILD}: ${COLOR_BUILD}%s${NOCOLOR})\n" \
        $((i + 1)) "$base_version" "$build_number"
    done

    printf "${COLOR_SELECT}%2d)${NOCOLOR} ${MSG_DOWNLOAD_ALL_FILES}\n" $((${#PT_VERSIONS[@]} + 1))
    printf "${COLOR_SELECT}%2d)${NOCOLOR} ${MSG_BACK_MAIN_MENU}\n" $((${#PT_VERSIONS[@]} + 2))
    printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

    read -p "${MSG_ENTER_OPTION} [1-$((${#PT_VERSIONS[@]} + 2))]: " choice

    if [ "$choice" -eq $((${#PT_VERSIONS[@]} + 2)) ]; then
      main_menu
      return
    elif [ "$choice" -eq $((${#PT_VERSIONS[@]} + 1)) ]; then
      # 选择下载所有文件
      for ver in "${PT_VERSIONS[@]}"; do
        local base_version="${ver%-*}"
        local url="https://download.parallels.com/toolbox/v7/${ver}/ParallelsToolbox-${ver}.dmg"
        local filename="ParallelsToolbox-${ver}.dmg"
        download_list+=("$url|$filename")
      done
    elif [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#PT_VERSIONS[@]}" ]; then
      # 选择单个文件
      local ver="${PT_VERSIONS[$((choice - 1))]}"
      local base_version="${ver%-*}"
      local url="https://download.parallels.com/toolbox/v7/${ver}/ParallelsToolbox-${ver}.dmg"
      local filename="ParallelsToolbox-${ver}.dmg"
      download_list+=("$url|$filename")
    else
      print_error "${MSG_INVALID_OPTION}"
      sleep 2
      batch_download_dmg
      return
    fi
  else
    print_error "${MSG_INVALID_OPTION}"
    sleep 2
    batch_download_dmg
    return
  fi

  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_INFO}${MSG_FILES_TO_DOWNLOAD}:${NOCOLOR}\n"

  for item in "${download_list[@]}"; do
    local url="${item%%|*}"
    local filename="${item#*|}"
    printf -- "- ${COLOR_VERSION}%s${NOCOLOR}\n" "$filename"
  done

  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_SELECT}1)${NOCOLOR} ${MSG_CONFIRM_DOWNLOAD}\n"
  printf "${COLOR_SELECT}2)${NOCOLOR} ${MSG_CANCEL}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"

  read -p "${MSG_ENTER_OPTION} [1-2]: " confirm

  if [ "$confirm" != "1" ]; then
    main_menu
    return
  fi

  # 使用download.sh中的batch_download_files函数
  source "scripts/download.sh"
  batch_download_files "${download_list[@]}"

  read -p "${MSG_PRESS_ANY_KEY}" -n 1 -s
  main_menu
}
