#!/bin/bash

[ -f "scripts/utils.sh" ] && source "scripts/utils.sh" || {
  echo "Error: utils.sh not found"
  exit 1
}

download_file() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"
  
  local url="$1"
  local filename="$2"
  local cache_dir="./downloads"
  
  [ ! -d "$cache_dir" ] && {
    mkdir -p "$cache_dir"
    sudo chmod 777 "$cache_dir"
    sudo chown $(whoami):$(id -gn) "$cache_dir"
  }
  
  local filepath="${cache_dir}/${filename}"
  
  if [ -f "$filepath" ]; then
    print_info "${MSG_FILE_EXISTS}: $filepath"
    sudo chmod 777 "$filepath"
    sudo chown $(whoami):$(id -gn) "$filepath"
    
    if [[ "$filepath" == *.dmg ]]; then
      mount_dmg "$filepath"
    fi
    
    return 0
  fi
  
  sudo chmod -R 777 "$cache_dir" 2>/dev/null
  
  print_info "${MSG_DOWNLOADING}: $url"
  print_info "${MSG_SAVING_TO}: $filepath"
  
  local total_size=$(curl -sI "$url" | grep -i "Content-Length" | awk '{print $2}' | tr -d '\r')
  
  if [ -n "$total_size" ] && [ "$total_size" -gt 0 ]; then
    download_with_progress "$url" "$filepath" "$total_size"
  else
    download_without_progress "$url" "$filepath"
  fi
  
  if [ ! -f "$filepath" ] || [ ! -s "$filepath" ]; then
    print_error "${MSG_EMPTY_FILE}"
    [ -f "$filepath" ] && rm -f "$filepath"
    return 1
  fi
  
  sudo chmod 777 "$filepath"
  sudo chown $(whoami):$(id -gn) "$filepath"
  
  if [ "$(stat -f "%p" "$filepath" 2>/dev/null)" != "100777" ]; then
    print_info "权限设置未生效，尝试其他方法..."
    sudo chmod -R 777 "$cache_dir"
    sudo chown -R $(whoami):$(id -gn) "$cache_dir"
  fi
  
  print_info "${MSG_DOWNLOAD_COMPLETE}: $filepath"
  print_info "${MSG_FILE_SIZE}: $(du -h "$filepath" | cut -f1)"
  
  if [[ "$filepath" == *.dmg ]]; then
    mount_dmg "$filepath"
  fi
  
  return 0
}

download_with_progress() {
  local url="$1"
  local filepath="$2"
  local total_size="$3"
  
  curl -L "$url" -o "$filepath" --retry 3 --connect-timeout 30 --silent > /dev/null 2>&1 &
  local curl_pid=$!
  
  local cols=$(tput cols)
  local bar_size=$((cols > 50 ? 40 : cols - 10))
  local downloaded=0
  local percent=0
  local bar=""
  local start_time=$(date +%s)
  
  printf "\n"
  while kill -0 $curl_pid 2>/dev/null; do
    if [ -f "$filepath" ]; then
      sudo chmod 777 "$filepath" 2>/dev/null
      
      downloaded=$(stat -f%z "$filepath" 2>/dev/null || echo 0)
      percent=$((downloaded * 100 / total_size))
      
      bar=""
      local completed=$((percent * bar_size / 100))
      for ((i=0; i<completed; i++)); do
        bar="${bar}█"
      done
      for ((i=completed; i<bar_size; i++)); do
        bar="${bar}░"
      done
      
      local current_time=$(date +%s)
      local elapsed=$((current_time - start_time))
      local speed=0
      [ $elapsed -gt 0 ] && speed=$((downloaded / elapsed))
      
      printf "\r[%s] %3d%% %s/%s (%s/s)   " \
        "$bar" \
        "$percent" \
        "$(numfmt --to=iec-i --suffix=B --format="%.2f" $downloaded 2>/dev/null || echo "${downloaded}B")" \
        "$(numfmt --to=iec-i --suffix=B --format="%.2f" $total_size 2>/dev/null || echo "${total_size}B")" \
        "$(numfmt --to=iec-i --suffix=B --format="%.2f" $speed 2>/dev/null || echo "${speed}B")"
    fi
    sleep 0.5
  done
  
  wait $curl_pid
  local exit_code=$?
  
  if [ $exit_code -eq 0 ]; then
    downloaded=$total_size
    percent=100
    bar=""
    local completed=$((percent * bar_size / 100))
    for ((i=0; i<completed; i++)); do
      bar="${bar}█"
    done
    
    local end_time=$(date +%s)
    local total_elapsed=$((end_time - start_time))
    local avg_speed=0
    [ $total_elapsed -gt 0 ] && avg_speed=$((downloaded / total_elapsed))
    
    printf "\r[%s] %3d%% %s/%s (%s/s)   \n" \
      "$bar" \
      "$percent" \
      "$(numfmt --to=iec-i --suffix=B --format="%.2f" $downloaded 2>/dev/null || echo "${downloaded}B")" \
      "$(numfmt --to=iec-i --suffix=B --format="%.2f" $total_size 2>/dev/null || echo "${total_size}B")" \
      "$(numfmt --to=iec-i --suffix=B --format="%.2f" $avg_speed 2>/dev/null || echo "${avg_speed}B")"
  fi
  
  if [ $exit_code -ne 0 ]; then
    print_error "${MSG_DOWNLOAD_FAILED}"
    [ -f "$filepath" ] && rm -f "$filepath"
    return 1
  fi
  
  local total_time=$(($(date +%s) - start_time))
  print_info "${MSG_DOWNLOAD_TIME}: ${total_time}${MSG_SECONDS}"
  
  return 0
}

download_without_progress() {
  local url="$1"
  local filepath="$2"
  
  echo "${MSG_DOWNLOADING}..."
  
  curl -L "$url" -o "$filepath" -s --retry 3 --connect-timeout 30 \
       --write-out "${MSG_DOWNLOAD_SPEED}: %{speed_download} bytes/s  ${MSG_DOWNLOAD_TIME}: %{time_total} s  ${MSG_FILE_SIZE}: %{size_download} bytes\n" || {
    print_error "${MSG_DOWNLOAD_FAILED}"
    [ -f "$filepath" ] && rm -f "$filepath"
    return 1
  }
  
  return 0
}

mount_dmg() {
  local filepath="$1"
  
  print_info "${MSG_MOUNTING_DMG}"
  local mount_output=$(hdiutil attach "$filepath" -nobrowse -noverify)
  print_info "$(echo "$mount_output" | tr '\n' ' ')"
  
  local last_line=$(echo "$mount_output" | tail -1)
  local mount_point=$(echo "$last_line" | sed -E 's|.*(\/Volumes\/[^[:space:]]+( [^[:space:]]+)*).*|\1|')
  
  [[ ! "$mount_point" == /Volumes/* ]] && mount_point="/Volumes/$(echo "$last_line" | awk -F'/' '{print $NF}')"
  
  if [ -n "$mount_point" ] && [ -d "$mount_point" ]; then
    print_info "${MSG_DMG_MOUNTED}: $mount_point"
    print_info "${MSG_INSTALL_FROM_MOUNT}"
    open "$mount_point"
  else
    print_error "${MSG_DMG_MOUNT_FAILED}"
    [ -d "/Volumes/Parallels Toolbox" ] && { open "/Volumes/Parallels Toolbox"; print_info "${MSG_OPENED} /Volumes/Parallels Toolbox"; } || \
    [ -d "/Volumes/Parallels Desktop" ] && { open "/Volumes/Parallels Desktop"; print_info "${MSG_OPENED} /Volumes/Parallels Desktop"; } || \
    print_error "${MSG_MANUAL_OPEN}: $filepath"
  fi
  
  return 0
}

# 批量下载文件但不自动挂载
batch_download_files() {
  LANGUAGE=$(get_global_language)
  load_language "$LANGUAGE"
  
  local download_list=("$@")
  local total_files=${#download_list[@]}
  local cache_dir="./downloads"
  
  [ ! -d "$cache_dir" ] && {
    mkdir -p "$cache_dir"
    sudo chmod 777 "$cache_dir"
    sudo chown $(whoami):$(id -gn) "$cache_dir"
  }
  
  # 初始化变量
  local filepaths=()
  local filenames=()
  local urls=()
  local total_sizes=()
  local downloaded_sizes=()
  local start_times=()
  local statuses=()
  local curl_pids=()
  local retry_counts=()
  local max_retries=3
  local max_parallel=4
  local active_downloads=0
  local next_task=0
  
  # 解析下载列表
  for ((i=0; i<total_files; i++)); do
    local item="${download_list[$i]}"
    local url="${item%%|*}"
    local filename="${item#*|}"
    local filepath="${cache_dir}/${filename}"
    
    urls[$i]="$url"
    filenames[$i]="$filename"
    filepaths[$i]="$filepath"
    total_sizes[$i]=0
    downloaded_sizes[$i]=0
    start_times[$i]=$(date +%s)
    curl_pids[$i]=""
    retry_counts[$i]=0
    
    if [ -f "$filepath" ]; then
      statuses[$i]="${MSG_FILE_EXISTS_SHORT}"
      print_info "${MSG_FILE_EXISTS}: $filepath"
      sudo chmod 777 "$filepath"
      sudo chown $(whoami):$(id -gn) "$filepath"
    else
      statuses[$i]="${MSG_WAITING}"
    fi
  done
  
  # 打印表头
  clear
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_TITLE}${MSG_BATCH_DOWNLOAD_PROGRESS}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  
  # 打印每个文件的初始状态
  for ((i=0; i<total_files; i++)); do
    printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [%s]\n" \
      $((i+1)) "${filenames[$i]}" "${statuses[$i]}"
  done
  
  # 设置一些显示参数
  local cols=$(tput cols)
  local bar_size=$((cols > 70 ? 40 : cols - 30))
  local all_done=0
  
  # 开始下载队列处理
  start_download() {
    local idx=$1
    local url="${urls[$idx]}"
    local filepath="${filepaths[$idx]}"
    
    # 获取文件大小
    print_info "${MSG_DOWNLOADING}: ${url}"
    print_info "${MSG_SAVING_TO}: ${filepath}"
    
    local size_output=$(curl -sI "${url}" | grep -i "Content-Length" | awk '{print $2}' | tr -d '\r')
    total_sizes[$idx]=${size_output:-0}
    
    # 开始下载
    statuses[$idx]="${MSG_DOWNLOADING_SHORT}"
    curl -L "${url}" -o "${filepath}" --retry 3 --connect-timeout 30 --silent > /dev/null 2>&1 &
    curl_pids[$idx]=$!
    ((active_downloads++))
  }
  
  # 处理已完成的下载
  process_completed_download() {
    local idx=$1
    local status=$2
    local filepath="${filepaths[$idx]}"
    
    if [ $status -eq 0 ] && [ -f "$filepath" ] && [ -s "$filepath" ]; then
      # 下载成功
      statuses[$idx]="${MSG_COMPLETED}"
      downloaded_sizes[$idx]=$(stat -f%z "$filepath" 2>/dev/null || echo 0)
      
      sudo chmod 777 "$filepath"
      sudo chown $(whoami):$(id -gn) "$filepath"
      
      ((active_downloads--))
      
      # 启动下一个排队的下载
      if [ $next_task -lt $total_files ]; then
        if [ "${statuses[$next_task]}" = "${MSG_WAITING}" ]; then
          start_download $next_task
          ((next_task++))
        else
          ((next_task++))
          while [ $next_task -lt $total_files ] && [ "${statuses[$next_task]}" != "${MSG_WAITING}" ]; do
            ((next_task++))
          done
          if [ $next_task -lt $total_files ] && [ "${statuses[$next_task]}" = "${MSG_WAITING}" ]; then
            start_download $next_task
            ((next_task++))
          fi
        fi
      fi
    else
      # 下载失败，需要重试
      retry_counts[$idx]=$((retry_counts[$idx] + 1))
      
      if [ ${retry_counts[$idx]} -lt $max_retries ]; then
        # 重试
        print_info "重试 ${filenames[$idx]} (${retry_counts[$idx]}/$max_retries)..."
        statuses[$idx]="${MSG_WAITING}"
        [ -f "$filepath" ] && rm -f "$filepath"
        
        # 立即重新开始下载
        start_download $idx
      else
        # 重试次数用尽
        statuses[$idx]="${MSG_FAILED}"
        [ -f "$filepath" ] && rm -f "$filepath"
        ((active_downloads--))
        
        # 启动下一个排队的下载
        if [ $next_task -lt $total_files ]; then
          if [ "${statuses[$next_task]}" = "${MSG_WAITING}" ]; then
            start_download $next_task
            ((next_task++))
          else
            ((next_task++))
            while [ $next_task -lt $total_files ] && [ "${statuses[$next_task]}" != "${MSG_WAITING}" ]; do
              ((next_task++))
            done
            if [ $next_task -lt $total_files ] && [ "${statuses[$next_task]}" = "${MSG_WAITING}" ]; then
              start_download $next_task
              ((next_task++))
            fi
          fi
        fi
      fi
    fi
  }
  
  # 启动初始的并行下载
  for ((i=0; i<max_parallel && i<total_files; i++)); do
    if [ "${statuses[$i]}" = "${MSG_WAITING}" ]; then
      start_download $i
      ((next_task++))
    else
      ((next_task++))
    fi
  done
  
  # 更新进度和处理完成/失败的下载
  while [ $all_done -eq 0 ]; do
    all_done=1
    
    # 移动光标到表头之后
    printf "\033[${total_files}A"
    
    for ((i=0; i<total_files; i++)); do
      if [ "${statuses[$i]}" = "${MSG_DOWNLOADING_SHORT}" ]; then
        all_done=0
        
        if [ -n "${curl_pids[$i]}" ] && kill -0 ${curl_pids[$i]} 2>/dev/null; then
          # 下载仍在进行
          if [ -f "${filepaths[$i]}" ]; then
            sudo chmod 777 "${filepaths[$i]}" 2>/dev/null
            downloaded_sizes[$i]=$(stat -f%z "${filepaths[$i]}" 2>/dev/null || echo 0)
            
            if [ ${total_sizes[$i]} -gt 0 ]; then
              local percent=$((downloaded_sizes[$i] * 100 / total_sizes[$i]))
              local current_time=$(date +%s)
              local elapsed=$((current_time - start_times[$i]))
              local speed=0
              [ $elapsed -gt 0 ] && speed=$((downloaded_sizes[$i] / elapsed))
              
              # 构建进度条
              local bar=""
              local completed=$((percent * bar_size / 100))
              for ((j=0; j<completed; j++)); do
                bar="${bar}█"
              done
              for ((j=completed; j<bar_size; j++)); do
                bar="${bar}░"
              done
              
              # 显示重试信息
              local retry_info=""
              [ ${retry_counts[$i]} -gt 0 ] && retry_info=" (${MSG_RETRY} ${retry_counts[$i]}/$max_retries)"
              
              # 清除当前行并更新
              printf "\033[K"
              printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [%3d%%] [%s] %s/s%s\n" \
                $((i+1)) "${filenames[$i]}" "$percent" "$bar" \
                "$(numfmt --to=iec-i --suffix=B --format="%.2f" $speed 2>/dev/null || echo "${speed}B")" \
                "$retry_info"
            else
              printf "\033[K"
              printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${MSG_DOWNLOADING_SHORT}] %s%s\n" \
                $((i+1)) "${filenames[$i]}" \
                "$(numfmt --to=iec-i --suffix=B --format="%.2f" ${downloaded_sizes[$i]} 2>/dev/null || echo "${downloaded_sizes[$i]}B")" \
                "$([ ${retry_counts[$i]} -gt 0 ] && echo " (${MSG_RETRY} ${retry_counts[$i]}/$max_retries)" || echo "")"
            fi
          else
            printf "\033[K"
            printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${MSG_PREPARING}]%s\n" \
              $((i+1)) "${filenames[$i]}" \
              "$([ ${retry_counts[$i]} -gt 0 ] && echo " (${MSG_RETRY} ${retry_counts[$i]}/$max_retries)" || echo "")"
          fi
        else
          # 检查下载是否完成
          if [ -n "${curl_pids[$i]}" ]; then
            wait ${curl_pids[$i]} 2>/dev/null
            local exit_status=$?
            process_completed_download $i $exit_status
          fi
        fi
      elif [ "${statuses[$i]}" = "${MSG_WAITING}" ]; then
        all_done=0
        printf "\033[K"
        printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${MSG_WAITING}]%s\n" \
          $((i+1)) "${filenames[$i]}" \
          "$([ ${retry_counts[$i]} -gt 0 ] && echo " (${MSG_RETRY} ${retry_counts[$i]}/$max_retries)" || echo "")"
      elif [ "${statuses[$i]}" = "${MSG_FILE_EXISTS_SHORT}" ]; then
        printf "\033[K"
        printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${COLOR_INFO}${MSG_FILE_EXISTS_SHORT}${NOCOLOR}]\n" \
          $((i+1)) "${filenames[$i]}"
      elif [ "${statuses[$i]}" = "${MSG_COMPLETED}" ]; then
        printf "\033[K"
        printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${COLOR_INFO}${MSG_COMPLETED}${NOCOLOR}] %s\n" \
          $((i+1)) "${filenames[$i]}" \
          "$(numfmt --to=iec-i --suffix=B --format="%.2f" ${downloaded_sizes[$i]} 2>/dev/null || echo "${downloaded_sizes[$i]}B")"
      elif [ "${statuses[$i]}" = "${MSG_FAILED}" ]; then
        printf "\033[K"
        printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [${COLOR_ERROR}${MSG_FAILED}${NOCOLOR}] (${MSG_MAX_RETRIES_REACHED})\n" \
          $((i+1)) "${filenames[$i]}"
      else
        printf "\033[K"
        printf "${COLOR_SELECT}%2d)${NOCOLOR} ${COLOR_VERSION}%-20s${NOCOLOR} [%s]\n" \
          $((i+1)) "${filenames[$i]}" "${statuses[$i]}"
      fi
    done
    
    # 如果没有活动的下载并且所有任务都已处理，则退出循环
    if [ $active_downloads -eq 0 ] && [ $next_task -ge $total_files ]; then
      # 再次检查是否所有任务都已完成或失败
      local all_completed=1
      for ((i=0; i<total_files; i++)); do
        if [[ "${statuses[$i]}" != "${MSG_COMPLETED}" && "${statuses[$i]}" != "${MSG_FAILED}" && "${statuses[$i]}" != "${MSG_FILE_EXISTS_SHORT}" ]]; then
          all_completed=0
          break
        fi
      done
      
      if [ $all_completed -eq 1 ]; then
        all_done=1
      fi
    fi
    
    sleep 0.5
  done
  
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_INFO}${MSG_ALL_DOWNLOADS_COMPLETED}${NOCOLOR}\n"
  printf "${COLOR_TITLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NOCOLOR}\n"
  printf "${COLOR_INFO}${MSG_FILES_SAVED_IN} ${cache_dir} ${MSG_DIRECTORY}${NOCOLOR}\n"
  printf "${COLOR_INFO}${MSG_OPEN_MANUALLY}${NOCOLOR}\n"
  
  # 显示下载结果摘要
  local success_count=0
  local fail_count=0
  local exist_count=0
  
  for ((i=0; i<total_files; i++)); do
    if [ "${statuses[$i]}" = "${MSG_COMPLETED}" ]; then
      ((success_count++))
    elif [ "${statuses[$i]}" = "${MSG_FAILED}" ]; then
      ((fail_count++))
    elif [ "${statuses[$i]}" = "${MSG_FILE_EXISTS_SHORT}" ]; then
      ((exist_count++))
    fi
  done
  
  printf "${COLOR_INFO}${MSG_DOWNLOAD_SUMMARY}: "
  printf "${COLOR_SUCCESS}${success_count} ${MSG_SUCCEEDED}${NOCOLOR}, "
  printf "${COLOR_ERROR}${fail_count} ${MSG_FAILED_SUMMARY}${NOCOLOR}, "
  printf "${COLOR_INFO}${exist_count} ${MSG_ALREADY_EXISTS}${NOCOLOR}\n"
  
  return 0
}
  return 0
}