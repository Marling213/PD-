#!/bin/bash

COLOR_INFO='\033[0;34m'
COLOR_ERROR='\033[0;31m'
COLOR_VERSION='\033[1;32m'
COLOR_BUILD='\033[1;33m'
COLOR_TITLE='\033[1;36m'
COLOR_SELECT='\033[0;35m'
NOCOLOR='\033[0m'

USER_LANG="${LANG:-}"
USER_LANGUAGE="${LANGUAGE:-}"
USER_LC_ALL="${LC_ALL:-}"

export SCRIPT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export SCRIPT_LANGUAGE="${SCRIPT_LANGUAGE:-}"

get_global_language() {
  if [ -n "$SCRIPT_LANGUAGE" ]; then
    echo "$SCRIPT_LANGUAGE"
  else
    detect_system_language
  fi
}

save_global_language() {
  export SCRIPT_LANGUAGE="$1"
}

detect_system_language() {
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"zh"* ]]; then
    echo "zh_CN"
    return
  fi
  
  if [[ -n "$USER_LANGUAGE" && "$USER_LANGUAGE" == *"zh"* ]]; then
    echo "zh_CN"
    return
  fi
  
  if [[ -n "$USER_LC_ALL" && "$USER_LC_ALL" == *"zh"* ]]; then
    echo "zh_CN"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"fr"* ]]; then
    echo "fr_FR"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"es"* ]]; then
    echo "es_ES"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"de"* ]]; then
    echo "de_DE"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"it"* ]]; then
    echo "it_IT"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"pt"* ]]; then
    echo "pt_BR"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"ru"* ]]; then
    echo "ru_RU"
    return
  fi
  
  if [[ -n "$USER_LANG" && "$USER_LANG" == *"ja"* ]]; then
    echo "ja_JP"
    return
  fi
  
  local sys_lang=$(defaults read -g AppleLocale 2>/dev/null || echo "en_US")
  case "${sys_lang:0:2}" in
    zh) echo "zh_CN" ;;
    fr) echo "fr_FR" ;;
    es) echo "es_ES" ;;
    de) echo "de_DE" ;;
    it) echo "it_IT" ;;
    pt) echo "pt_BR" ;;
    ru) echo "ru_RU" ;;
    ja) echo "ja_JP" ;;
    *) echo "en_US" ;;
  esac
}

LANGUAGE=$(get_global_language)
[ -z "$LANGUAGE" ] && LANGUAGE=$(detect_system_language)

load_language() {
  local new_language="$1"
  
  if [ -n "$new_language" ]; then
    LANGUAGE="$new_language"
    save_global_language "$LANGUAGE"
  fi
  
  local lang_file="${SCRIPT_PATH}/../lang/${LANGUAGE}.sh"
  if [ -f "$lang_file" ]; then
    source "$lang_file"
    return 0
  else
    printf "${COLOR_ERROR}[Error] Language file $lang_file not found!${NOCOLOR}\n"
    printf "${COLOR_INFO}[Info] Falling back to English${NOCOLOR}\n"
    LANGUAGE="en_US"
    save_global_language "$LANGUAGE"
    
    lang_file="${SCRIPT_PATH}/../lang/en_US.sh"
    if [ -f "$lang_file" ]; then
      source "$lang_file"
      return 0
    else
      printf "${COLOR_ERROR}[Error] No language files found!${NOCOLOR}\n"
      exit 1
    fi
  fi
}

load_language

print_info() { printf "${COLOR_INFO}[${MSG_INFO}] %s${NOCOLOR}\n" "$1"; }
print_error() { printf "${COLOR_ERROR}[${MSG_ERROR}] %s${NOCOLOR}\n" "$1"; return 1; }
print_success() { printf "${COLOR_VERSION}[${MSG_SUCCESS}] %s${NOCOLOR}\n" "$1"; }

check_permission_error() {
  if echo "$1" | grep -q "Operation not permitted"; then
    printf "${COLOR_ERROR}[${MSG_PERMISSION_ERROR}] %s: ${MSG_OPERATION_NOT_PERMITTED}${NOCOLOR}\n" "$3"
    printf "${COLOR_ERROR}[${MSG_PERMISSION_ERROR}] ${MSG_GRANT_TERMINAL_PERMISSION}${NOCOLOR}\n"
    printf "${COLOR_ERROR}[${MSG_PERMISSION_ERROR}] ${MSG_PERMISSION_PATH}${NOCOLOR}\n"
    return 1
  fi
  return 0
}

show_unknown_error() {
  printf "${COLOR_ERROR}[${MSG_UNKNOWN_ERROR}] %s ${MSG_OPERATION_FAILED}${NOCOLOR}\n" "$2"
  [ -n "$1" ] && printf "${COLOR_ERROR}[${MSG_ERROR}] %s${NOCOLOR}\n" "$1"
  printf "${COLOR_ERROR}[${MSG_INFO}] ${MSG_CHECK_PERMISSION}${NOCOLOR}\n"
}

run_cmd() {
  local cmd="$1"
  local err_msg="$2"
  local operation="$3"
  
  output=$(eval "$cmd" 2>&1)
  status=$?
  
  if [ $status -ne 0 ]; then
    check_permission_error "$output" "$status" "$operation" && exit 1 || {
      print_error "$err_msg"
      show_unknown_error "$output" "$operation"
      exit 1
    }
  fi
  
  return 0
}

check_root() {
  [ "$EUID" -ne 0 ] && {
    printf "${COLOR_ERROR}[Error] Please run this script with sudo!${NOCOLOR}\n"
    exit 1
  }
}

init() {
  check_root
  load_language
}